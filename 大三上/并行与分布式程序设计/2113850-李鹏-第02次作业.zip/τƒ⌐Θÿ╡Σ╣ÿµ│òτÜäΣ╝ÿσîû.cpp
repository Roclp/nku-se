#include <iostream>
#include <windows.h>
#include <pmmintrin.h>
#include <cstdlib>
#include <algorithm>
#include <fstream>
#include<iomanip>
using namespace std;

const long long maxN = 10000+1; // 调整为所需的矩阵大小
const int T = 64;      // 块大小
int n;
float a[maxN][maxN];
float b[maxN][maxN];
float c[maxN][maxN];

LARGE_INTEGER head, tail, freq; // 计时器

// 计时器函数
void start_timer()
{
    QueryPerformanceFrequency(&freq);
    QueryPerformanceCounter(&head);
}

double get_timer()
{
    QueryPerformanceCounter(&tail);
    return static_cast<double>(tail.QuadPart - head.QuadPart) / freq.QuadPart;
}

// 矩阵乘法
void mul(int n, float a[][maxN], float b[][maxN], float c[][maxN])
{
    for (int i = 0; i < n; ++i)
    {
        for (int j = 0; j < n; ++j)
        {
            c[i][j] = 0.0;
            for (int k = 0; k < n; ++k)
            {
                c[i][j] += a[i][k] * b[k][j];
            }
        }
    }
}

// 转置矩阵乘法
void trans_mul(int n, float a[][maxN], float b[][maxN], float c[][maxN])
{
    // 转置矩阵
    for (int i = 0; i < n; ++i)
    {
        for (int j = 0; j < i; ++j)
        {
            swap(b[i][j], b[j][i]);
        }
    }

    for (int i = 0; i < n; ++i)
    {
        for (int j = 0; j < n; ++j)
        {
            c[i][j] = 0.0;
            for (int k = 0; k < n; ++k)
            {
                c[i][j] += a[i][k] * b[j][k];
            }
        }
    }

    // 恢复转置矩阵
    for (int i = 0; i < n; ++i)
    {
        for (int j = 0; j < i; ++j)
        {
            swap(b[i][j], b[j][i]);
        }
    }
}

// SSE矩阵乘法
void sse_mul(int n, float a[][maxN], float b[][maxN], float c[][maxN])
{
    // 转置矩阵
    for (int i = 0; i < n; ++i)
    {
        for (int j = 0; j < i; ++j)
        {
            swap(b[i][j], b[j][i]);
        }
    }

    for (int i = 0; i < n; ++i)
    {
        for (int j = 0; j < n; ++j)
        {
            c[i][j] = 0.0;
            __m128 sum = _mm_setzero_ps();

            for (int k = 0; k < n; k += 4)
            {
                __m128 t1 = _mm_load_ps(a[i] + k);
                __m128 t2 = _mm_load_ps(b[j] + k);
                t1 = _mm_mul_ps(t1, t2);
                sum = _mm_add_ps(sum, t1);
            }

            float t[4];
            _mm_store_ps(t, sum);
            c[i][j] += t[0] + t[1] + t[2] + t[3];
        }
    }

    // 恢复转置矩阵
    for (int i = 0; i < n; ++i)
    {
        for (int j = 0; j < i; ++j)
        {
            swap(b[i][j], b[j][i]);
        }
    }
}

// SSE矩阵乘法带切片
void sse_tile(int n, float a[][maxN], float b[][maxN], float c[][maxN])
{
    // 转置矩阵
    for (int i = 0; i < n; ++i)
    {
        for (int j = 0; j < i; ++j)
        {
            swap(b[i][j], b[j][i]);
        }
    }

    __m128 t1, t2, sum;
    float t;

    for (int r = 0; r < n / T; ++r)
        for (int q = 0; q < n / T; ++q)
        {
            for (int i = 0; i < T; ++i)
                for (int j = 0; j < T; ++j)
                    c[r * T + i][q * T + j] = 0.0;

            for (int p = 0; p < n / T; ++p)
            {
                for (int i = 0; i < T; ++i)
                    for (int j = 0; j < T; ++j)
                    {
                        sum = _mm_setzero_ps();

                        for (int k = 0; k < T; k += 4)
                        {
                            t1 = _mm_loadu_ps(a[r * T + i] + p * T + k);
                            t2 = _mm_loadu_ps(b[q * T + j] + p * T + k);
                            t1 = _mm_mul_ps(t1, t2);
                            sum = _mm_add_ps(sum, t1);
                        }

                        _mm_store_ss(&t, sum);
                        c[r * T + i][q * T + j] += t;
                    }
            }
        }

    // 恢复转置矩阵
    for (int i = 0; i < n; ++i)
    {
        for (int j = 0; j < i; ++j)
        {
            swap(b[i][j], b[j][i]);
        }
    }
}

void show(float c[][maxN],int n)
{
    for(int i=0; i<n; i++)
    {
        for(int j=0; j<n; j++)
        {
            cout<<c[i][j]<<" ";
        }
        cout<<endl;
    }
}



int main()
{

    int count=10;   // 每种算法循环count次计算平均耗时
    ofstream outputFile("data.csv");
    outputFile << "Matrix Size: " << "x" << n << ","<<"mul"<<","<<"trans_mul"<<","<<"sse_mul"<<","<<"sse_tile"<<endl;

    for (int n=5; n<=1000; n=n+5)
    {
        // 初始化矩阵a和b
        for (int i = 0; i < n; ++i)
        {
            for (int j = 0; j < n; ++j)
            {
                a[i][j] = static_cast<float>(rand()) / RAND_MAX;
                b[i][j] = static_cast<float>(rand()) / RAND_MAX;
            }
        }
        outputFile<<n<<"×"<<n<<",";
        double result[4]={0.0};
        for(int k=0; k<count; k++)
        {
            // 测试mul函数
            start_timer();
            mul(n, a, b, c);
            //cout << "mul函数 - 经过时间：" << get_timer() << " 秒" << endl;
            //show(c,n);
            result[0]+=get_timer();

            // 测试trans_mul函数
            start_timer();
            trans_mul(n, a, b, c);
            //cout << "trans_mul函数 - 经过时间：" << get_timer() << " 秒" << endl;
            //show(c,n);
            result[1]+=get_timer();

            // 测试sse_mul函数
            start_timer();
            sse_mul(n, a, b, c);
            //cout << "sse_mul函数 - 经过时间：" << get_timer() << " 秒" << endl;
            //show(c,n);
            result[2]+=get_timer();

            // 测试sse_tile函数
            start_timer();
            sse_tile(n, a, b, c);
            //cout << "sse_tile函数 - 经过时间：" << get_timer() << " 秒" << endl;
            //show(c,n);
            result[3]+=get_timer();
        }
        outputFile<< setprecision(8) << fixed<<result[0]/count<<","<<result[1]/count<<","<<result[2]/count<<","<<result[3]/count<<endl;
    }
    outputFile.close();
    return 0;
}
