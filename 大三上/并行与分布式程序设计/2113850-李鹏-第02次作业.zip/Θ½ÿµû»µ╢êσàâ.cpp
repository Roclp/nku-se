#include <iostream>
#include <immintrin.h> // SSE/AVX头文件
#include <chrono>
#include <random>

// 定义问题规模和矩阵大小
const int N = 1000;

// SSE/AVX向量大小
const int SSE_WIDTH = 4; // 32位SSE为4，256位AVX为8

// 生成随机矩阵A和向量B
void generateRandomMatrix(float A[N][N], float B[N]) {
    std::random_device rd;
    std::mt19937 gen(rd());
    std::uniform_real_distribution<float> dist(1.0, 10.0);

    for (int i = 0; i < N; i++) {
        B[i] = dist(gen);
        for (int j = 0; j < N; j++) {
            A[i][j] = dist(gen);
        }
    }
}

// SSE版本的高斯消元法
void gaussianEliminationSSE(float A[N][N], float B[N]) {
    for (int i = 0; i < N; i++) {
        for (int j = i + 1; j < N; j++) {
            float factor = A[j][i] / A[i][i];
            for (int k = i; k < N; k++) {
                A[j][k] -= factor * A[i][k];
            }
            B[j] -= factor * B[i];
        }
    }

    for (int i = N - 1; i >= 0; i--) {
        float diag = A[i][i];
        for (int j = i + 1; j < N; j++) {
            B[i] -= A[i][j] * B[j];
        }
        B[i] /= diag;
    }
}

// AVX版本的高斯消元法
void gaussianEliminationAVX(float A[N][N], float B[N]) {
    for (int i = 0; i < N; i++) {
        for (int j = i + 1; j < N; j++) {
            float factor = A[j][i] / A[i][i];
            __m256 factor_vector = _mm256_set1_ps(factor);
            for (int k = i; k < N; k += 8) {
                __m256 a_row = _mm256_loadu_ps(&A[i][k]);
                __m256 b_row = _mm256_loadu_ps(&A[j][k]);
                b_row = _mm256_fmadd_ps(factor_vector, a_row, b_row);
                _mm256_storeu_ps(&A[j][k], b_row);
            }
            B[j] -= factor * B[i];
        }
    }

    for (int i = N - 1; i >= 0; i--) {
        float diag = A[i][i];
        __m256 diag_vector = _mm256_set1_ps(diag);
        for (int j = i + 1; j < N; j++) {
            B[i] -= A[i][j] * B[j];
        }
        B[i] /= diag;
    }
}

int main() {
    float A[N][N];
    float B[N];

    // 生成随机矩阵A和向量B
    generateRandomMatrix(A, B);

    // 计算SSE版本的高斯消元法执行时间
    auto sse_start = std::chrono::high_resolution_clock::now();
    gaussianEliminationSSE(A, B); // 使用SSE版本
    auto sse_end = std::chrono::high_resolution_clock::now();
    std::chrono::duration<double> sse_duration = sse_end - sse_start;

    // 重新生成随机矩阵A和向量B
    generateRandomMatrix(A, B);

    // 计算AVX版本的高斯消元法执行时间
    auto avx_start = std::chrono::high_resolution_clock::now();
    gaussianEliminationAVX(A, B); // 使用AVX版本
    auto avx_end = std::chrono::high_resolution_clock::now();
    std::chrono::duration<double> avx_duration = avx_end - avx_start;

    // 输出性能比较结果
    std::cout << "SSE Execution Time: " << sse_duration.count() << " seconds" << std::endl;
    std::cout << "AVX Execution Time: " << avx_duration.count() << " seconds" << std::endl;

    return 0;
}
