#include <iostream>
#include <algorithm>
#include <vector>
#include <time.h>
#include <wmmintrin.h>
#include <immintrin.h>
#include <windows.h>
#include <pthread.h>
#include <fstream>
using namespace std;

typedef struct
{
    int threadId;
} threadParm_t;

const int ARR_LEN = 1000;
const int THREAD_NUM = 8;
pthread_mutex_t amutex = PTHREAD_MUTEX_INITIALIZER;
long long head, freq; // timers

vector<int> arr[1000000];

void init()
{
    srand(unsigned(time(nullptr)));
    for (int i = 0; i < ARR_LEN; i++)
    {
        arr[i].resize(ARR_LEN);
        for (int j = 0; j < ARR_LEN; j++)
            arr[i][j] = rand();
    }
}

void init_2()
{
    int ratio;
    srand(unsigned(time(nullptr)));
    for (int i = 0; i < ARR_LEN; i++)
    {
        arr[i].resize(ARR_LEN);
        ratio = (rand() & 127);
        if (ratio < 32)
            for (int j = 0; j < ARR_LEN; j++)
            {
                arr[i][j] = ARR_LEN - j;
            }
        else
            for (int j = 0; j < ARR_LEN; j++)
            {
                arr[i][j] = j;
            }
    }
}

void *arr_sort(void *parm)
{
    threadParm_t *p = (threadParm_t *)parm;
    int r = p->threadId;
    long long tail;
    for (int i = r * ARR_LEN / THREAD_NUM; i < (r + 1) * ARR_LEN / THREAD_NUM; i++)
        sort(arr[i].begin(), arr[i].end());
    pthread_mutex_lock(&amutex);
    QueryPerformanceCounter((LARGE_INTEGER *)&tail);
    cout << "Thread " << r << ": " << (tail - head) * 1000.0 / freq << "ms." << endl;
    pthread_mutex_unlock(&amutex);
    pthread_exit(nullptr);
}

int next_arr = 0;
pthread_mutex_t mutex_task = PTHREAD_MUTEX_INITIALIZER;

void *arr_sort_fine(void *parm)
{
    threadParm_t *p = (threadParm_t *)parm;
    int r = p->threadId;
    int task = 0;
    long long tail;
    while (1)
    {
        pthread_mutex_lock(&mutex_task);
        task = next_arr++;
        pthread_mutex_unlock(&mutex_task);
        if (task >= ARR_LEN)
            break;
        stable_sort(arr[task].begin(), arr[task].end());
    }
    pthread_mutex_lock(&amutex);
    QueryPerformanceCounter((LARGE_INTEGER *)&tail);
    cout << "Thread " << r << ": " << (tail - head) * 1000.0 / freq << "ms." << endl;
    pthread_mutex_unlock(&amutex);
    pthread_exit(nullptr);
}

int main()
{
    long long tail;
    ofstream outputFile("data2.csv", ios::out);

    if (!outputFile.is_open())
    {
        cerr << "Error opening file!" << endl;
        return 1;
    }

    outputFile << "规模," << "数组元素随机 动态划分," << "数组元素指定 动态划分," << "数组元素随机 静态划分," << "数组元素指定 静态划分" << endl;

    QueryPerformanceFrequency((LARGE_INTEGER *)&freq);

    pthread_t thread[THREAD_NUM];
    threadParm_t threadParm[THREAD_NUM];

    for (int curr_ARR_LEN = 100; curr_ARR_LEN <= 10000; curr_ARR_LEN += 100)
    {
        init();
        outputFile << curr_ARR_LEN << "*" << curr_ARR_LEN << ",";

        cout << "数组元素随机 动态划分\n";
        QueryPerformanceCounter((LARGE_INTEGER *)&head);
        amutex = PTHREAD_MUTEX_INITIALIZER;

        for (int i = 0; i < THREAD_NUM; i++)
        {
            threadParm[i].threadId = i;
            pthread_create(&thread[i], nullptr, arr_sort_fine, (void *)&threadParm[i]);
        }

        for (int i = 0; i < THREAD_NUM; i++)
        {
            pthread_join(thread[i], nullptr);
        }

        pthread_mutex_destroy(&amutex);

        QueryPerformanceCounter((LARGE_INTEGER *)&tail);
        outputFile << (tail - head) * 1000.0 / freq << ",";

        init_2();
        cout << "数组元素指定 动态划分\n";
        QueryPerformanceCounter((LARGE_INTEGER *)&head);
        amutex = PTHREAD_MUTEX_INITIALIZER;

        for (int i = 0; i < THREAD_NUM; i++)
        {
            threadParm[i].threadId = i;
            pthread_create(&thread[i], nullptr, arr_sort_fine, (void *)&threadParm[i]);
        }

        for (int i = 0; i < THREAD_NUM; i++)
        {
            pthread_join(thread[i], nullptr);
        }

        pthread_mutex_destroy(&amutex);

        QueryPerformanceCounter((LARGE_INTEGER *)&tail);
        outputFile << (tail - head) * 1000.0 / freq << ",";

        init();
        cout << "数组元素随机 静态划分\n";
        QueryPerformanceCounter((LARGE_INTEGER *)&head);
        amutex = PTHREAD_MUTEX_INITIALIZER;

        for (int i = 0; i < THREAD_NUM; i++)
        {
            threadParm[i].threadId = i;
            pthread_create(&thread[i], nullptr, arr_sort, (void *)&threadParm[i]);
        }

        for (int i = 0; i < THREAD_NUM; i++)
        {
            pthread_join(thread[i], nullptr);
        }

        pthread_mutex_destroy(&amutex);

        QueryPerformanceCounter((LARGE_INTEGER *)&tail);
        outputFile << (tail - head) * 1000.0 / freq << ",";

        init_2();
        cout << "数组元素指定 静态划分\n";
        QueryPerformanceCounter((LARGE_INTEGER *)&head);
        amutex = PTHREAD_MUTEX_INITIALIZER;

        for (int i = 0; i < THREAD_NUM; i++)
        {
            threadParm[i].threadId = i;
            pthread_create(&thread[i], nullptr, arr_sort, (void *)&threadParm[i]);
        }

        for (int i = 0; i < THREAD_NUM; i++)
        {
            pthread_join(thread[i], nullptr);
        }

        pthread_mutex_destroy(&amutex);

        QueryPerformanceCounter((LARGE_INTEGER *)&tail);
        outputFile << (tail - head) * 1000.0 / freq << endl;
    }

    outputFile.close();
    return 0;
}
