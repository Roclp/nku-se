#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <windows.h>

#define N 100
#define NUM_THREADS 4

// 全局变量
double A[N][N], B[N], X[N];
pthread_barrier_t barrier;

// 高斯消元法函数
void *gaussianElimination(void *arg) {
    int thread_id = *((int *)arg);
    int start = thread_id * (N / NUM_THREADS);
    int end = (thread_id + 1) * (N / NUM_THREADS);

    for (int k = 0; k < N - 1; k++) {
        // 消元阶段
        for (int i = start + 1; i < end; i++) {
            double factor = A[i][k] / A[k][k];
            for (int j = k; j < N; j++) {
                A[i][j] -= factor * A[k][j];
            }
            B[i] -= factor * B[k];
        }

        // 同步线程
        pthread_barrier_wait(&barrier);

        // 回代阶段
        if (thread_id == 0) {
            for (int i = start; i < end; i++) {
                X[i] = B[i] / A[i][i];
            }
        }

        // 同步线程
        pthread_barrier_wait(&barrier);
    }

    pthread_exit(NULL);
}

int main() {
    // 初始化矩阵A和向量B
    for (int i = 0; i < N; i++) {
        for (int j = 0; j < N; j++) {
            A[i][j] = rand() % 10 + 1;  // 为了简化，随机生成1到10之间的值
        }
        B[i] = rand() % 100 + 1;  // 为了简化，随机生成1到100之间的值
    }

    // 初始化Pthread屏障
    pthread_barrier_init(&barrier, NULL, NUM_THREADS);

    // 创建线程标识符
    pthread_t threads[NUM_THREADS];
    int thread_ids[NUM_THREADS];

    // 使用QueryPerformanceCounter进行计时
    LARGE_INTEGER frequency, start_time, end_time;
    QueryPerformanceFrequency(&frequency);
    QueryPerformanceCounter(&start_time);

    // 创建线程
    for (int i = 0; i < NUM_THREADS; i++) {
        thread_ids[i] = i;
        pthread_create(&threads[i], NULL, gaussianElimination, (void *)&thread_ids[i]);
    }

    // 等待线程结束
    for (int i = 0; i < NUM_THREADS; i++) {
        pthread_join(threads[i], NULL);
    }

    // 使用QueryPerformanceCounter结束计时
    QueryPerformanceCounter(&end_time);
    double execution_time = (double)(end_time.QuadPart - start_time.QuadPart) / frequency.QuadPart;

    // 销毁屏障
    pthread_barrier_destroy(&barrier);

    // 打印解向量X
    printf("解向量X:\n");
    for (int i = 0; i < N; i++) {
        printf("%lf ", X[i]);
    }
    printf("\n");

    // 打印执行时间
    printf("执行时间: %lf秒\n", execution_time);

    return 0;
}
