#include <mpi.h>
#include <stdio.h>
#include <math.h>

// 定义全局常量
#define TOTAL_NUM 1000
#define BEGIN_NUM 1.0
#define END_NUM 8.0

// 全局变量，表示总面积和步长
double totalSize = 0.0;
double gap = 0.0;

// 函数f(x)
double f(double x)
{
    return x * x * x + 2 * x * x + x + 1;
}

// 函数：计算部分面积
double cal(int begin, int size)
{
    double temp_size = 0.0;
    for (int i = begin; i < fmin(begin + size, TOTAL_NUM); ++i)
    {
        // 使用梯形法则计算部分面积
        temp_size += (f(BEGIN_NUM + gap * i) + f(BEGIN_NUM + gap * (i + 1))) * gap / 2;
    }
    return temp_size;
}

int main(int argc, char *argv[])
{
    // 计算步长
    gap = (END_NUM - BEGIN_NUM) / TOTAL_NUM;
    int rank, thread_num;

    MPI_Init(&argc, &argv);
    MPI_Comm_rank(MPI_COMM_WORLD, &rank);
    MPI_Comm_size(MPI_COMM_WORLD, &thread_num);

    // 每个线程都分配这么(size*rand)多个任务，主线程不分配
    int each_thread_size = TOTAL_NUM / (thread_num - 1) + 1;

    if (rank != 0)
    {
        double buf;
        // 计算每个线程的部分面积
        buf = cal((rank - 1) * each_thread_size, each_thread_size);
        // 发送部分面积到主线程
        MPI_Send(&buf, 1, MPI_DOUBLE, 0, 0, MPI_COMM_WORLD);
    }

    if (rank == 0)
    {
        for (int i = 1; i < thread_num; ++i)
        {
            double temp_size;
            // 接收各个线程的部分面积，并累加
            MPI_Recv(&temp_size, 1, MPI_DOUBLE, i, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
            totalSize += temp_size;
        }
        // 输出总面积
        printf("Total size: %lf\n", totalSize);
    }

    MPI_Finalize();
    return MPI_SUCCESS;
}
