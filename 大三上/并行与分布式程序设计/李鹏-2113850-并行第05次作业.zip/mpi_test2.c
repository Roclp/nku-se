#include <mpi.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#define ARR_NUM 100       // 固定数组大小
#define ARR_LEN 4000      // 固定数组长度
#define SEG 50            // 粗颗粒的分配大小

int arr[ARR_NUM][ARR_LEN];

// 初始化数组
void init() {
    srand(time(NULL));
    for (int i = 0; i < ARR_NUM; i++) {
        for (int j = 0; j < ARR_LEN; j++)
            arr[i][j] = rand() % 100;
    }
}

// 执行任务：对数组的部分进行排序
void doTask(int begin) {
    for (int i = begin; i < (begin + SEG < ARR_NUM ? begin + SEG : ARR_NUM); ++i) {
        qsort(arr[i], ARR_LEN, sizeof(int), cmp);
    }
}

// 用于 qsort 的比较函数
int cmp(const void* a, const void* b) {
    return (*(int*)a - *(int*)b);
}

int main() {
    init();
    int current_task = 0; // 当前的任务
    int rank, thread_num;
    MPI_Init(NULL, NULL);
    MPI_Comm_rank(MPI_COMM_WORLD, &rank);
    MPI_Comm_size(MPI_COMM_WORLD, &thread_num);
    MPI_Status status;
    int ready;
    int done = 0;

    if (rank == 0) {
        while (current_task < ARR_NUM) {
            MPI_Recv(&ready, 1, MPI_INT, MPI_ANY_SOURCE, MPI_ANY_TAG, MPI_COMM_WORLD, &status);
            MPI_Send(&current_task, 1, MPI_INT, status.MPI_SOURCE, 0, MPI_COMM_WORLD);
            current_task += SEG;
        }
        printf("success\n");
        done = 1;
    } else {
        while (!done) {
            int begin;
            MPI_Send(&ready, 1, MPI_INT, 0, 0, MPI_COMM_WORLD);
            MPI_Recv(&begin, 1, MPI_INT, 0, 0, MPI_COMM_WORLD, &status);
            doTask(begin);
        }
    }

    MPI_Finalize();
    return 0;
}
