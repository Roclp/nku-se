#include <iostream>
#include <pthread.h>
#include <cstdint>

using namespace std;

const int thread_count = 4;

double a = 1.0;
double b = 10.0;
int n = 1000;
double h;

double result = 0.0;
pthread_mutex_t mutex;

// Function to be integrated
double f(double x) {
    //return 1;
    return 3*x*x + 2*x + x + 6;
}

void* Local_trap(void* rank) {
    intptr_t my_rank = reinterpret_cast<intptr_t>(rank);
    int local_n = n / thread_count;
    double local_a = a + my_rank * local_n * h;
    double local_b = local_a + local_n * h;

    double local_result = (f(local_a) + f(local_b)) / 2.0;

    for (int i = 1; i <= local_n - 1; i++) {
        double x = local_a + i * h;
        local_result += f(x);
    }

    local_result = local_result * h;

    pthread_mutex_lock(&mutex);
    result += local_result;
    pthread_mutex_unlock(&mutex);

    return NULL;
}

int main() {
    h = (b - a) / n;
    pthread_t* thread_handles;
    pthread_mutex_init(&mutex, NULL);

    thread_handles = (pthread_t*)malloc(thread_count * sizeof(pthread_t));

    for (intptr_t thread = 0; thread < thread_count; thread++) {
        pthread_create(&thread_handles[thread], NULL, Local_trap, reinterpret_cast<void*>(thread));
    }

    for (intptr_t thread = 0; thread < thread_count; thread++) {
        pthread_join(thread_handles[thread], NULL);
    }

    cout << result << endl;

    free(thread_handles);
    pthread_mutex_destroy(&mutex);

    return 0;
}
