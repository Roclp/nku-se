#include <iostream>
#include <omp.h>

using namespace std;

int thread_count = 4;

double f(double x)
{
    // return 1;
    return 3*x*x + 2*x + x + 6;
}

double Local_trap(double a, double b, int n)
{
    double h, x, my_result;
    int i;

    h = (b - a) / n;

    my_result = (f(a) + f(b)) / 2.0;
    int local_n = n / thread_count; // �����ܵ����������߳������� local_n

    for (i = 1; i <= local_n; i++)
    {
        x = a + i * h;
        my_result += f(x);
    }
    my_result = my_result * h;
    return my_result;
}

int main()
{
    double global_result = 0.0;

    int a = 1, b = 10;
    int n = 1000;

    #pragma omp parallel num_threads(thread_count) reduction(+ : global_result)
    {
        double local_result = Local_trap(a, b, n);

        #pragma omp critical
        global_result += local_result;
    }

    cout << global_result << endl;
    return 0;
}
