#include <stdio.h>
#include <stdlib.h>
#include <omp.h>

#define ARRAY_SIZE 10000
#define NUM_ARRAYS 5

// 生成随机数组
void generateArrays(int arrays[NUM_ARRAYS][ARRAY_SIZE]) {
    for (int i = 0; i < NUM_ARRAYS; ++i) {
        for (int j = 0; j < ARRAY_SIZE; ++j) {
            arrays[i][j] = rand() % 1000;
        }
    }
}

// 打印数组
void printArrays(int arrays[NUM_ARRAYS][ARRAY_SIZE]) {
    for (int i = 0; i < NUM_ARRAYS; ++i) {
        printf("数组 %d: ", i);
        for (int j = 0; j < ARRAY_SIZE; ++j) {
            printf("%d ", arrays[i][j]);
        }
        printf("\n");
    }
}

// 用于qsort比较的函数
int compareIntegers(const void *a, const void *b) {
    return (*(int *)a - *(int *)b);
}

// 对数组进行排序
void sortArrays(int arrays[NUM_ARRAYS][ARRAY_SIZE], int num_threads, int chunk_size, int dynamic) {
    #pragma omp parallel for num_threads(num_threads) schedule(dynamic, chunk_size)
    for (int i = 0; i < NUM_ARRAYS; ++i) {
        // 使用快速排序对单个数组进行排序
        qsort(arrays[i], ARRAY_SIZE, sizeof(int), compareIntegers);
    }
}

int main() {
    int arrays[NUM_ARRAYS][ARRAY_SIZE];

    // 生成随机数组
    generateArrays(arrays);

    // 打印未排序的数组
    printf("未排序的数组:\n");
    printArrays(arrays);

    // 设置OpenMP参数
    int num_threads[] = {2, 4, 8};
    int chunk_sizes[] = {1, 10, 100};
    int dynamic_values[] = {0, 1}; // 0表示静态，1表示动态

    // 测试不同配置
    for (int i = 0; i < sizeof(num_threads) / sizeof(num_threads[0]); ++i) {
        for (int j = 0; j < sizeof(chunk_sizes) / sizeof(chunk_sizes[0]); ++j) {
            for (int k = 0; k < sizeof(dynamic_values) / sizeof(dynamic_values[0]); ++k) {
                int num_thread = num_threads[i];
                int chunk_size = chunk_sizes[j];
                int dynamic = dynamic_values[k];

                printf("\n配置: 线程数=%d, 块大小=%d, 动态=%d\n", num_thread, chunk_size, dynamic);

                // 使用当前配置对数组进行排序
                sortArrays(arrays, num_thread, chunk_size, dynamic);

                // 打印排序后的数组
                printf("排序后的数组:\n");
                printArrays(arrays);
            }
        }
    }

    return 0;
}
