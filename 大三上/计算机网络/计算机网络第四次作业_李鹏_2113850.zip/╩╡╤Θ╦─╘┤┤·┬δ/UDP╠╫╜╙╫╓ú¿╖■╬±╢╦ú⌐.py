from socket import *
import random
# 创建一个UDP套接字(SOCK_DGRAM)
serverSocket = socket(AF_INET, SOCK_DGRAM)

# 将套接字绑定到指定地址和端口
serverSocket.bind(('127.0.0.1', 12000))

while True:
    rand = random.randint(0, 10)
    message, address = serverSocket.recvfrom(1024)
    message = message.upper()

    # 模拟30%的数据包丢失
    if rand < 4:
        continue

    # 发送响应消息给客户端
    serverSocket.sendto(message, address)

serverSocket.close()