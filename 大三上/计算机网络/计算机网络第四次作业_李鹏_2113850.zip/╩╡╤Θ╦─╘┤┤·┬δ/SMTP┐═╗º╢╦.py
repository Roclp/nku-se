# python实现SMTP客户端

from socket import *
import sys
import base64

# 邮件内容
msg = "\r\n send an email from lipeng"
# 消息以单个 . 结束。
endmsg = "\r\n.\r\n"

# 选择一个邮件服务器
mailserver = 'smtp.163.com'
mailserver_SMTP_Port = 25
mailserver_SMTP_LoginID  = base64.b64encode(b'test5213208@163.com').decode() + '\r\n'
mailserver_SMTP_Password = base64.b64encode(b'EOYPXVDCZVTABAXM').decode() + '\r\n'

# 163 授权码 EOYPXVDCZVTABAXM
# QQ 授权码 vuzchrajlftsdcfc

From = 'test5213208@163.com'
To = '3149334565@qq.com'

# 创建 socket 和邮件服务器建立 TCP 连接
clientSocket = socket(AF_INET,SOCK_STREAM)
clientSocket.connect((mailserver,mailserver_SMTP_Port))
recv = clientSocket.recv(1024).decode()
print(recv,end = '')
if recv[:3] != '220':
    print('220 reply not received from server.')
    clientSocket.close()
    exit(0)

# 发送 HELO 命令，打印服务器响应
heloCommand = 'HELO 163.com\r\n'
clientSocket.send(heloCommand.encode())
recv1 = clientSocket.recv(1024).decode()
print(recv1,end = '')
if recv1[:3] != '250':
    print('250 reply not received from server.')
    clientSocket.close()
    exit(0)

logCommand = 'AUTH LOGIN\r\n'
clientSocket.send(logCommand.encode())
recv2 = clientSocket.recv(1024).decode()
print(recv2,end = '')
if recv2[:3] != '334':
    print('334 login server goes wrong')
    clientSocket.close()
    exit(0)

clientSocket.send(mailserver_SMTP_LoginID.encode())
recv3 = clientSocket.recv(1024).decode()
print(recv3,end = '')
if recv3[:3] == '535':
    print('Login ID wrong')
    clientSocket.close()
    exit(0)

clientSocket.send(mailserver_SMTP_Password.encode())
recv4 = clientSocket.recv(1024).decode()
print(recv4,end = '')
if recv4[:3] == '535':
    print('Password wrong')
    clientSocket.close()
    exit(0)

# 发送 MAIL FROM 命令，打印服务器响应
fromCommand = 'MAIL FROM ' + '<' + From + '>' + '\r\n'
clientSocket.send(fromCommand.encode())
recv = clientSocket.recv(2048).decode()
print(recv,end = '')
if recv[:3] != '250':
    print('Mail From server goes wrong')
    clientSocket.close()
    exit(0)

# 发送 RCPT TO 命令，打印服务器响应
toCommand = 'RCPT TO: ' + '<' + To + '>' + '\r\n'
clientSocket.send(toCommand.encode())
recv6 = clientSocket.recv(1024).decode()
print(recv6,end = '')
if recv6[:3] != '250':
    print('Mail to server goes wrong')
    clientSocket.close()
    exit(0)

# 发送 DATA 命令，打印服务器响应
beginCommand = 'DATA\r\n'
clientSocket.send(beginCommand.encode())
recv7 = clientSocket.recv(1024).decode()
print(recv7,end = '')
if recv7[:3] != '354':
    print('Data Begin server goes wrong')
    clientSocket.close()
    exit(0)

# 发送邮件内容
send = "From: " + From + '\r\n'
send += "To: " + To + '\r\n'
send += "Subject: " + "First Web Mail Test From lipeng" + '\r\n'
send += msg
clientSocket.send(send.encode())
clientSocket.send(endmsg.encode())
recv8 = clientSocket.recv(1024).decode()
print(recv8, end='')
if recv8[:3] != '250':
    print('Data Transport goes wrong')
    clientSocket.close()
    exit(0)

endCommand = 'QUIT\r\n'
clientSocket.send(endCommand.encode())
recv9 = clientSocket.recv(1024).decode()
print(recv9, end='')
if recv9[:3] != '221':
    print('server end goes wrong')
    clientSocket.close()
    exit(0)
clientSocket.close()

