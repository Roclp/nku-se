from socket import *
import time

IP = '127.0.0.1'
PORT = 12000
TIMEOUT = 1  # 1秒超时

# 实例化一个socket对象，指明UDP协议
dataSocket = socket(AF_INET, SOCK_DGRAM)

for i in range(10):
    # 记录发送数据包之前的时间
    start_time = time.time()

    # 发送UDP数据，将数据发送到套接字
    dataSocket.sendto(f'Ping {i}'.encode(), (IP, PORT))

    try:
        # 设置接收响应的超时时间
        dataSocket.settimeout(TIMEOUT)
        # 接收服务端的消息
        recved, addr = dataSocket.recvfrom(1024)
        # 如果返回空bytes，表示对方关闭了连接
        if not recved:
            break
        # 计算往返时间（RTT）
        rtt = time.time() - start_time
        # 打印响应消息和RTT
        print(f'来自 {addr} 的响应：{recved.decode()} - 往返时间：{rtt:.6f} 秒')

    except timeout:
        # 处理超时
        print(f'Ping {i} 请求超时')

dataSocket.close()
