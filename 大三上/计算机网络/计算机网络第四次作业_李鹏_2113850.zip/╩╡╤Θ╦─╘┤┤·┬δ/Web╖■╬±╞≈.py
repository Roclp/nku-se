from socket import *
import os

# 设置服务器地址和端口
serverAddress = ('127.0.0.1', 6789)

# 创建服务器套接字
serverSocket = socket(AF_INET, SOCK_STREAM)

# 绑定服务器地址和端口
serverSocket.bind(serverAddress)

# 设置最大连接数
serverSocket.listen(10)
print("Web server is ready to receive requests.")

while True:
    # 等待客户端连接
    print("Waiting for a connection...")
    connectionSocket, addr = serverSocket.accept()

    try:
        # 接收客户端请求数据
        message = connectionSocket.recv(1024).decode()

        # 打印请求报文
        filename=message.split()[1]

        filename=filename[1:]
        print(filename)
        
         # 检查文件是否存在
        if os.path.isfile(filename):
            # 打开并读取文件内容
            with open(filename, 'rb') as file:
                content = file.read()

            # 构建 HTTP 响应报文
            response = "HTTP/1.1 200 OK \r\n\r\n".encode() + content

        else:
            # 文件不存在，返回 404 Not Found 响应
            response = "HTTP/1.1 404 Not Found 请求失败\r\n\r\n".encode()

        connectionSocket.send(response)

    except IOError:
        response = "HTTP/1.1 404 Not Found 请求失败\r\n\r\n".encode()
        connectionSocket.send(response)
        connectionSocket.close()
        

# 关闭服务器套接字
server_socket.close()
