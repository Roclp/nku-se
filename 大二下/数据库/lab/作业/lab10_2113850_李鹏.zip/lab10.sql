select count(*),grade
from takes
where course_id='192' and sec_id=1 and semester='Fall' and year=2002
group by grade
order by grade;

select count(*),grade
from takes
where grade=null;

drop procedure if exists course_score;

delimiter $$
create procedure course_score(
	in c varchar(5),sec varchar(8),s varchar(6),y decimal(4,0))
    begin 
		select count(*),grade
		from takes
		where course_id=c and sec_id=sec and semester=s and year=y
		group by takes.grade
		order by takes.grade;
	end$$
delimiter ;

call course_score('192',1,'Fall',2002);
call course_score('493',1,'Spring',2010);
