
import matplotlib.pyplot as plt
import pymysql

# 连接数据库
conn = pymysql.connect(host='127.0.0.1', user='myuser', password='Lp200211', database='dbsclab2018', charset='utf8')
cursor = conn.cursor()

# 获取用户输入的课程 ID
c = input('请输入course_id：')
sec=int(input('请输入sec_id: '))
s=input('请输入semester: ')
y=int(input('请输入year: '))


def get_score_cnt(course_id,sec_id,semester,year):
    cursor.callproc('course_score', (course_id, sec_id, semester, year,))
    retdata=cursor.fetchall()
    return retdata

precourses = get_score_cnt(c,sec,s,y);


# 关闭游标和连接
cursor.close()
conn.close()

# 输出结果
print(precourses)
print(type(precourses))


import matplotlib.pyplot as plot
import tkinter
import random
cnt_list=[]
name_list=[]
colors=[]
for i in range(len(precourses)):
    cnt_list.append(precourses[i][0])
    name_list.append(precourses[i][1])
    r, g, b = random.randint(0, 255), random.randint(0, 255), random.randint(0, 255)
    colors.append((r / 255.0, g / 255.0, b / 255.0))
print(cnt_list)
print(name_list)
index=[i for i in range(len(name_list))]
plt.bar(range(len(cnt_list)),cnt_list,color=colors)
plt.xticks(index,name_list)
plt.show()

fig=plt.figure()
plt.pie(cnt_list,labels=name_list,colors=colors,autopct='%1.2f%%')
plt.show()